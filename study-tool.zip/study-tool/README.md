# Study Deck — Setup & Publishing Guide

## What this is
A flashcard + quiz app that runs in any phone's browser (Android, iPhone, anything) and can be installed like a real app. It works fully offline once opened once, and saves your decks on the device.

## Step 1 — Try it right now
Open `index.html` in any phone or computer browser. Create a deck, add cards, study, take a quiz.

## Step 2 — Put it online (required before Play Store)
Play Store apps need a real web address to wrap. Easiest free options:
1. **GitHub Pages** (free, recommended):
   - Create a free GitHub account at github.com
   - Create a new repository, upload all these files (index.html, manifest.json, service-worker.js, icons folder)
   - Go to repo Settings → Pages → set source to your main branch
   - You'll get a link like `https://yourname.github.io/study-deck/`
2. Alternatives: Netlify.com or Vercel.com — drag-and-drop the whole folder, get a live link instantly.

## Step 3 — Wrap it as an Android app
Go to **https://www.pwabuilder.com**
1. Paste your live link (from Step 2) into the box and click "Start"
2. PWABuilder scans your app and confirms it's installable
3. Click **"Package for Stores" → Android**
4. Download the generated **.aab** file (Android App Bundle) — this is what Play Store needs

## Step 4 — Publish on Play Store
1. Go to https://play.google.com/console/signup and register ($25 one-time fee, card payment)
2. Complete identity verification
3. Once approved, click "Create app" in Play Console
4. Fill in app name ("Study Deck"), description, upload a screenshot (just screenshot your phone using the app)
5. Upload the .aab file from Step 3 under "Production" release
6. Fill in the required Content Rating questionnaire and Privacy Policy link (you can write a simple one — the app doesn't collect any personal data since everything is stored on the device)
7. Submit for review — usually takes a few hours to a few days

## Notes
- All your decks/cards are stored locally on each device using the browser's storage — nothing is sent to a server, so no backend or database costs.
- To add more features later (e.g. syncing across devices, spaced repetition scheduling), that would need a backend — happy to help with that when you're ready.
